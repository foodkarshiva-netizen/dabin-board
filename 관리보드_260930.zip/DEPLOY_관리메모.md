# 다빈보드 📝 관리메모 탭 — 배포 안내 (2026-09-30 관리보드 AI · 본부장 CT 방#1 글#28·#36)

적으면 관리보드 [📝 메모]와 같은 곳에 쌓이고(히스토리 포함), AI 가 보통 5분 안에 확인 답을 단다. 서버 쪽(memo_ext.php)은 이미 올라가 있고 시험 끝.

- 기준 원본 = 지금 깃허브 main 의 index.html (md5 f28af705f8c718406aa9a12676d1b036, 126,985 bytes)
- 방법 1: 이 폴더의 index.html 로 통째로 바꾸기 — 라이브가 위 md5 와 같을 때만(그 사이 누가 고쳤으면 방법 2)
- 방법 2: 라이브 index.html 에 아래 6곳을 old→new 로 바꾸기(dabin-board-deploy 메모의 GitHub 웹에디터 cmTile.view 치환). 6곳 모두 원본에 딱 한 번씩 있음

## ① 탭 목록(TABS) — 세션 오더 다음에 📝 관리메모

**old**
```
['debate','🗣','세션 오더'],
```
**new**
```
['debate','🗣','세션 오더'],['amemo','📝','관리메모'],
```

## ② 탭 아이콘(ICONS) — 끝에 amemo 아이콘

**old**
```
dreport:ic('<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>')};
```
**new**
```
dreport:ic('<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>'),amemo:ic('<path d="M5 3.5h14a1.5 1.5 0 0 1 1.5 1.5v10a1.5 1.5 0 0 1-1.5 1.5h-9l-4.5 4v-4H5A1.5 1.5 0 0 1 3.5 15V5A1.5 1.5 0 0 1 5 3.5z"/><path d="M8 8.5h8M8 12h5"/>')};
```

## ③ 탭 열 때(go) — 관리메모 탭이면 불러오기

**old**
```
if(id==='debate'){renderDChat();dScrollBot()}}
```
**new**
```
if(id==='debate'){renderDChat();dScrollBot()}if(id==='amemo')amOn()}
```

## ④ 화면 칸(CSS) — 채팅처럼 세로로 꽉 차게

**old**
```
#p-talk.on,#p-debate.on{display:flex;flex-direction:column;flex:1;min-height:0}
```
**new**
```
#p-talk.on,#p-debate.on,#p-amemo.on{display:flex;flex-direction:column;flex:1;min-height:0}
```

## ⑤ 화면(HTML) — 오늘 탭 앞에 관리메모 페이지

**old**
```
  <section class="page" id="p-today">
```
**new**
```
  <section class="page" id="p-amemo">
    <div class="small muted" style="margin:0 2px 8px">관리보드 📝 메모와 같은 곳이에요 — 여기 적어도 관리보드 메모·히스토리에 쌓이고, AI가 보통 5분 안에 확인 답을 달아요.</div>
    <div class="chat" id="amChat"><div class="empty">불러오는 중…</div></div>
    <div class="composer"><textarea id="amMsg" rows="2" placeholder="관리보드 메모 남기기"></textarea><button class="btn p" onclick="amSend()">남기기</button></div>
  </section>
  <section class="page" id="p-today">
```

## ⑥ 동작(JS) — startApp 바로 앞에 관리메모 함수

**old**
```
function startApp(){
```
**new**
```
/* ===== 📝 관리메모 — 관리보드(service.masterc.co.kr) 메모와 한 곳 (2026-09-30, 관리보드 AI) =====
   적으면 관리보드 [📝 메모]·히스토리에 쌓이고 AI 가 확인 답을 단다. 서버가 로그인한 구글 계정 토큰으로 본인 확인(foodkarshiva@gmail.com 만). */
var AM_API='https://service.masterc.co.kr/mastercco-access/memo_ext.php',AM_T=null,AM_SIG='';
function amCall(opt){var u=firebase.auth().currentUser;if(!u)return Promise.reject(new Error('로그인 필요'));return u.getIdToken().then(function(t){opt=opt||{};opt.headers=Object.assign({'Authorization':'Bearer '+t,'X-Id-Token':t},opt.headers||{});return fetch(AM_API,opt)}).then(function(r){return r.json()})}
function amLoad(){var c=document.getElementById('amChat');return amCall().then(function(d){if(!d.ok){c.innerHTML='<div class="empty">불러오지 못했어요 ('+esc(d.err||'')+')</div>';return}
  var L=d.rows||[],sig=L.map(function(m){return m.id+':'+(m.ai_ack?1:0)}).join(',');if(sig===AM_SIG&&c.children.length)return;AM_SIG=sig;var last='';
  c.innerHTML=L.length?L.map(function(m){var day=String(m.created_at||'').slice(0,10),h='';if(day!==last){last=day;h+='<div class="small muted" style="text-align:center;margin:6px 0">'+esc(day)+'</div>'}
    var me=m.who_email===d.me;h+='<div class="brow '+(me?'me':'cl')+'"><div class="bub">'+esc(m.body||'')+'</div><div class="bmeta">'+esc(m.who_name||'')+' · '+esc(String(m.created_at||'').slice(11,16))+' · '+esc(m.via||'관리보드')+'</div></div>';
    h+=m.ai_ack?'<div class="brow cl"><div class="bub" style="background:#f0fdf4;border-color:#bbf7d0">🤖 '+esc(m.ai_ack)+'</div><div class="bmeta">'+esc(String(m.ai_ack_at||'').slice(11,16))+'</div></div>':'<div class="small muted" style="text-align:'+(me?'right':'left')+';margin:-4px 4px 4px">🤖 확인 대기</div>';return h}).join(''):'<div class="empty">아직 메모가 없어요</div>';
  c.scrollTop=c.scrollHeight}).catch(function(e){c.innerHTML='<div class="empty">불러오지 못했어요: '+esc(e.message)+'</div>'})}
function amSend(){var el=document.getElementById('amMsg'),v=el.value.trim();if(!v)return;el.disabled=true;amCall({method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({body:v})}).then(function(d){el.disabled=false;if(!d.ok){alert('남기지 못했어요: '+(d.err||''));return}el.value='';AM_SIG='';amLoad()}).catch(function(e){el.disabled=false;alert('남기지 못했어요: '+e.message)})}
function amOn(){AM_SIG='';amLoad();if(AM_T)clearInterval(AM_T);AM_T=setInterval(function(){var p=document.getElementById('p-amemo');if(p&&p.classList.contains('on')&&!document.hidden)amLoad()},60000)}
function startApp(){
```

## 올린 뒤 확인
- 다빈보드 → 📝 관리메모 탭 → 메모 한 줄 남기기 → 관리보드 📝 메모에 「윤다빈 · 다빈보드에서」로 보이면 끝(AI 가 5분 안에 확인 답)
- 「불러오지 못했어요 (not_allowed)」 = 허용 계정(foodkarshiva@gmail.com)이 아님 · (bad_token) = 다시 로그인